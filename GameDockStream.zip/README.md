# GameDock Stream

Il motore di streaming dell'app GameDock TV: è **Moonlight per Android** (https://github.com/moonlight-stream/moonlight-android,
licenza **GNU GPL v3**) con il nome, l'icona e la firma di GameDock, senza icona nel menu della TV.
GameDock lo apre direttamente nello streaming del gioco: non vedi mai i menu di Moonlight.

Lo streaming, la qualità e i controller sono esattamente quelli di Moonlight: tutto il merito tecnico è del progetto Moonlight.

## Cosa viene modificato (patch_moonlight.py)
- nome del pacchetto `com.lollomarta.gamedock.stream` (convive con Moonlight, come chiede il suo autore);
- nome "GameDock Stream", icona e banner di GameDock;
- nessuna icona nel menu della TV (si apre da GameDock: Impostazioni › Streaming);
- firma fissa (`assets/gamedock.jks`) per aggiornarlo senza disinstallarlo.

## Come crearlo (GitHub, senza installare niente)
1. Nuovo repository privato `GameDockStream`.
2. Crea il file `.github/workflows/build-stream.yml` incollando il contenuto di quello in questa cartella.
3. Add file › Upload files › carica `GameDockStream.zip` › Commit.
4. Actions › al pallino verde scarica **GameDock-Stream-APK** (10-15 minuti la prima volta).
5. Metti `GameDock-Stream.apk` nella cartella `apk` di GameDock Agent: dall'app GameDock TV lo installi con un tasto
   (Impostazioni › Streaming › Installa GameDock Stream).

## Licenza
GameDock Stream è un'opera derivata di Moonlight ed è distribuito sotto **GPL v3** (vedi il file LICENSE di Moonlight).
Se lo dai ad altre persone devi rendere disponibile anche il codice sorgente: basta questa cartella (lo script delle
modifiche) insieme al link del codice di Moonlight v12.2. L'app GameDock è un programma separato che lo avvia
e non è coinvolta dalla licenza.
