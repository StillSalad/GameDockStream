"""
GameDock Stream - applica a Moonlight Android (GPLv3) le modifiche di GameDock.

Uso:  python3 patch_moonlight.py <cartella moonlight-android> <cartella GameDockStream>

Modifiche (nient'altro viene toccato: lo streaming resta quello di Moonlight):
- nome del pacchetto com.lollomarta.gamedock.stream (convive con Moonlight, come chiede il suo autore)
- nome "GameDock Stream", icona e banner di GameDock
- nessuna icona nel menu della TV: lo apre GameDock (ShortcutTrampoline e PcView restano esportati)
- firma fissa (keystore di GameDock) per poterlo aggiornare senza disinstallarlo
"""

import os
import re
import shutil
import sys

ML, ME = sys.argv[1], sys.argv[2]
APP = os.path.join(ML, "app")
PKG = "com.lollomarta.gamedock.stream"


def edit(path, pairs):
    with open(path, encoding="utf-8") as f:
        s = f.read()
    for pattern, repl, count in pairs:
        s, n = re.subn(pattern, repl, s, count=count, flags=re.S)
        if n == 0:
            sys.exit(f"ERRORE: modifica non applicata in {path}: {pattern}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(s)


# 1) build.gradle: pacchetto, nome, firma
shutil.copy(os.path.join(ME, "assets", "gamedock.jks"), os.path.join(APP, "gamedock.jks"))
edit(os.path.join(APP, "build.gradle"), [
    (r'applicationId "com\.limelight"', f'applicationId "{PKG}"', 1),
    (r'(buildTypes \{\s*debug \{)\s*applicationIdSuffix "\.debug"', r'\1', 1),
    (r'resValue "string", "app_label", "Moonlight \(Debug\)"', 'resValue "string", "app_label", "GameDock Stream"', 1),
    (r'resValue "string", "app_label_root", "Moonlight \(Root Debug\)"', 'resValue "string", "app_label_root", "GameDock Stream (Root)"', 1),
    (r'(buildTypes \{\s*debug \{)', r'\1\n            signingConfig signingConfigs.gamedock', 1),
    (r'(\n    buildTypes \{)', "\n    signingConfigs {\n        gamedock {\n            storeFile file('gamedock.jks')\n"
                              "            storePassword 'gamedock'\n            keyAlias 'gamedock'\n            keyPassword 'gamedock'\n"
                              "        }\n    }\n\\1", 1),
])

# 2) manifest: niente icona nel menu della TV (resta l'azione MAIN, apribile da GameDock)
edit(os.path.join(APP, "src", "main", "AndroidManifest.xml"), [
    (r'\s*<category android:name="android\.intent\.category\.LAUNCHER" />', '', 1),
    (r'\s*<category android:name="android\.intent\.category\.MULTIWINDOW_LAUNCHER" />', '', 1),
    (r'\s*<category android:name="android\.intent\.category\.LEANBACK_LAUNCHER" />', '', 1),
])

# 3) icona e banner di GameDock
res = os.path.join(APP, "src", "main", "res")
for d in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"):
    shutil.copy(os.path.join(ME, "assets", f"ic_launcher-{d}.png"), os.path.join(res, f"mipmap-{d}", "ic_launcher.png"))
for adaptive in ("ic_launcher.xml", "ic_launcher_round.xml"):
    p = os.path.join(res, "mipmap-anydpi-v26", adaptive)
    if os.path.exists(p):
        os.remove(p)                      # l'icona "adattiva" di Moonlight avrebbe la precedenza sulla nostra
shutil.copy(os.path.join(ME, "assets", "atv_banner.png"), os.path.join(res, "drawable-xhdpi", "atv_banner.png"))

print(f"GameDock Stream: modifiche applicate ({PKG})")
